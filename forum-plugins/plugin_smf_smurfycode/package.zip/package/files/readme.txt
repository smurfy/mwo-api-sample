This mod enabled the new bbc code smurfy

Which allows easy including of mwo.smurfy-net.de links to your forum.